.. highlight:: sh

Installation
============

Installation information is now maintained collaboratively in the 
`PyCUDA Wiki <http://wiki.tiker.net/PyCuda/Installation>`_.
